<?php $__env->startSection('title', 'Pengajuan Buku Premium'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin-premium.css')); ?>">

<div class="ap-page">
    <div class="ap-header">
        <div>
            <span class="ap-eyebrow">
                <i class="fa-solid fa-clipboard-check"></i> SAFAE ADMIN
            </span>
            <h1>Pengajuan <span>Buku Premium</span></h1>
            <p>Periksa dan kelola pengajuan premium dari penulis Safae.</p>
        </div>
        <a href="<?php echo e(route('admin.premium.books')); ?>" class="ap-header-link">
            <i class="fa-solid fa-crown"></i> Kelola Buku Premium
        </a>
    </div>

    <?php $__currentLoopData = ['success', 'error', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($type)): ?>
            <div class="ap-alert <?php echo e($type); ?>">
                <i class="fa-solid fa-circle-info"></i> <?php echo e(session($type)); ?>

            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="ap-stats ap-stats-four">
        <div class="ap-stat">
            <div class="ap-stat-icon blue"><i class="fa-solid fa-file-lines"></i></div>
            <div><strong><?php echo e($totalRequests); ?></strong><span>Total Pengajuan</span></div>
        </div>
        <div class="ap-stat">
            <div class="ap-stat-icon yellow"><i class="fa-solid fa-clock"></i></div>
            <div><strong><?php echo e($totalPending); ?></strong><span>Menunggu</span></div>
        </div>
        <div class="ap-stat">
            <div class="ap-stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
            <div><strong><?php echo e($totalApproved); ?></strong><span>Disetujui</span></div>
        </div>
        <div class="ap-stat">
            <div class="ap-stat-icon red"><i class="fa-solid fa-circle-xmark"></i></div>
            <div><strong><?php echo e($totalRejected); ?></strong><span>Ditolak</span></div>
        </div>
    </div>

    <div class="ap-panel">
        <div class="ap-panel-header">
            <div>
                <h2><i class="fa-solid fa-inbox"></i> Daftar Pengajuan</h2>
                <p>Tinjau buku sebelum menyetujui status premium.</p>
            </div>
            <span class="ap-count"><?php echo e($requests->total()); ?> Pengajuan</span>
        </div>

        <form method="GET" action="<?php echo e(route('admin.premium.index')); ?>" class="ap-filter">
            <div class="ap-search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                    placeholder="Cari judul buku atau penulis...">
            </div>
            <select name="status" class="ap-select">
                <option value="">Semua Status</option>
                <option value="pending" <?php if(request('status') === 'pending'): echo 'selected'; endif; ?>>Menunggu</option>
                <option value="approved" <?php if(request('status') === 'approved'): echo 'selected'; endif; ?>>Disetujui</option>
                <option value="rejected" <?php if(request('status') === 'rejected'): echo 'selected'; endif; ?>>Ditolak</option>
            </select>
            <button type="submit" class="ap-btn primary">
                <i class="fa-solid fa-filter"></i> Terapkan
            </button>
            <?php if(request('search') || request('status')): ?>
                <a href="<?php echo e(route('admin.premium.index')); ?>" class="ap-btn secondary">Reset</a>
            <?php endif; ?>
        </form>

        <div class="ap-table-wrap">
            <table class="ap-table">
                <thead>
                    <tr>
                        <th>Buku</th>
                        <th>Penulis</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $book = $item->book;
                            $cover = $book?->image_path
                                ? preg_replace('#^(public/|storage/)+#', '', $book->image_path)
                                : null;
                        ?>
                        <tr>
                            <td>
                                <div class="ap-table-book">
                                    <?php if($cover): ?>
                                        <img src="<?php echo e(asset('storage/'.$cover)); ?>"
                                            alt="<?php echo e($book?->title); ?>">
                                    <?php else: ?>
                                        <div class="ap-table-cover-empty">
                                            <i class="fa-solid fa-book"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?php echo e($book?->title ?? 'Buku tidak tersedia'); ?></strong>
                                        <small><?php echo e($book?->genre ?? '-'); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php echo e($book?->author ?: ($item->user?->username ?? '-')); ?>

                            </td>
                            <td><?php echo e($item->created_at?->format('d M Y') ?? '-'); ?></td>
                            <td>
                                <span class="ap-status <?php echo e($item->status); ?>">
                                    <?php echo e(match($item->status) {
                                        'pending' => 'Menunggu',
                                        'approved' => 'Disetujui',
                                        'rejected' => 'Ditolak',
                                        default => ucfirst($item->status)
                                    }); ?>

                                </span>
                            </td>
                            <td>
                                <div class="ap-table-actions">
                                    <?php if($item->status === 'pending' && $book): ?>
                                        <form action="<?php echo e(route('admin.premium.approve', $item->id)); ?>"
                                            method="POST"
                                            onsubmit="return confirm('Setujui pengajuan premium buku ini?')">
                                            <?php echo csrf_field(); ?>
                                            <button class="ap-btn success" type="submit">
                                                <i class="fa-solid fa-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('admin.premium.reject', $item->id)); ?>"
                                            method="POST"
                                            onsubmit="return confirm('Tolak pengajuan premium buku ini?')">
                                            <?php echo csrf_field(); ?>
                                            <button class="ap-btn danger" type="submit">
                                                <i class="fa-solid fa-xmark"></i> Tolak
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="ap-muted">Sudah diproses</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="ap-table-empty">
                                Belum ada pengajuan premium yang sesuai.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($requests->hasPages()): ?>
            <div class="ap-pagination"><?php echo e($requests->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutsAdmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TA\safaeLaravel\resources\views/admin/premium/index.blade.php ENDPATH**/ ?>