<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::table('reading_histories', function (Blueprint $table) {
        $table->string('bukti_progress')->nullable()->after('progress');
    });
}

public function down()
{
    Schema::table('reading_histories', function (Blueprint $table) {
        $table->dropColumn('bukti_progress');
    });
}

};
